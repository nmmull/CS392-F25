#![allow(dead_code, unused_variables, unreachable_code, unused_mut)] // REMOVE THIS WHEN YOU'RE DONE
use std::collections::HashMap;
use std::ops::Deref;
use std::ops::DerefMut;

// ---------------------
// CAS CS 392 M1 Midterm
// ---------------------
//
// From the textbook: "the Rust programming language is fundamentally
// about empowerment: no matter what kind of code you are writing now,
// Rust empowers you to reach farther..."
//
// I hope the first part of the course has given you this sense. But,
// for better or for worse, I only really like writing one kind of
// program: interpreters and compilers. So, for the midterm you'll be
// doing this. And then, in the second half of the course, you can
// build whatever /you/ want to build.
//
// In this exam, you will be reimplementing what you built in
// Assignment 3, but in Rust. You'll be given a paper version of the
// spec that you need to implement, along with some starter code, and
// a couple tests at the end. Good luck and have fun.
//
// Note: The spec for this midterm is slightly different from that of
// Assignment 3, in order to fix the issue we discussed in lecture.
//
// Note: If you finish early, there isn't much in terms of a "hard
// mode" here, feel free to leave early.
//
// Note: Don't be discouraged if you don't get to everything. Try to
// pass as many of the tests that you can. I'm mostly trying to see
// how you think in Rust.  This exam is also just as much about
// reading Rust as it is about writing it.

type Ident = u32;

#[derive(Clone, Copy, PartialEq, Debug)]
enum Mutability {
    Mut,
    Imm,
}

// ---------
// PROBLEM 1
// ---------
//
// Design enumerations for expressions and statements. You should use
// ~Ident~ for variable identifiers. (We're using ~u32~ to save on
// clones and to pretend like we have string interning). Make sure to
// fill in the constructors below, these are used in the tests.
//
// Note: One notable difference between this and the OCaml version is
// it's easier to just keep track of the number of dereferences in a
// place expression.  You can use a recursive ADT for place
// expressions, but it make sure to implement the constructor for
// place expressions correctly.

enum Expr {}

impl Expr {
    fn unit() -> Expr {
        todo!()
    }

    fn int32(n: i32) -> Expr {
        todo!()
    }

    fn place(derefs: u8, var: Ident) -> Expr {
        todo!()
    }

    fn borrow(derefs: u8, var: Ident) -> Expr {
        todo!()
    }

    fn assign(x: Ident, e: Expr) -> Expr {
        todo!()
    }
}

enum Stmt {}

impl Stmt {
    fn assign(x: Ident, e: Expr) -> Stmt {
        todo!()
    }

    fn let_imm(x: Ident, e: Expr) -> Stmt {
        todo!()
    }

    fn let_mut(x: Ident, e: Expr) -> Stmt {
        todo!()
    }
}

struct Prog {
    stmts: Vec<Stmt>,
    expr: Expr,
}

impl Prog {
    fn new(stmts: Vec<Stmt>, expr: Expr) -> Prog {
        Prog { stmts, expr }
    }
}

impl<const N: usize> From<[Stmt; N]> for Prog {
    fn from(stmts: [Stmt; N]) -> Prog {
        Prog::new(Vec::from(stmts), Expr::unit())
    }
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum Ty {
    Unit,
    Int32,
    Borrow(Ident),
}

impl Ty {
    fn unit() -> Ty {
        Ty::Unit
    }

    fn int32() -> Ty {
        Ty::Int32
    }

    fn borrow(x: Ident) -> Ty {
        Ty::Borrow(x)
    }
}

#[derive(Clone, Copy, PartialEq, Debug)]
struct SlotTy {
    ty: Ty,
    mutable: Mutability,
}

impl SlotTy {
    fn new(ty: Ty, mutable: Mutability) -> SlotTy {
        SlotTy { ty, mutable }
    }
}

#[derive(Clone, PartialEq, Debug)]
struct Context(HashMap<Ident, SlotTy>);

impl Context {
    fn new() -> Context {
        Context(HashMap::new())
    }
}

// ---------
// PROBLEM 2
// ---------
//
// Implement the ~From~ trait for ~Context~. For each triple of the
// form ~(x, ty, m)~ in ~bindings~, the identifier ~x~ should be
// mapped to ~ty~ with mutability ~m~.  Take a look at the Rust
// documentation for details about this trait, as well as the
// implementation above for ~Program~.

impl<const N: usize> From<[(Ident, Ty, Mutability); N]> for Context {
    fn from(_bindings: [(Ident, Ty, Mutability); N]) -> Context {
        todo!()
    }
}

impl Deref for Context {
    type Target = HashMap<Ident, SlotTy>;

    fn deref(&self) -> &HashMap<Ident, SlotTy> {
        &self.0
    }
}

impl DerefMut for Context {
    fn deref_mut(&mut self) -> &mut HashMap<Ident, SlotTy> {
        &mut self.0
    }
}

// ---------
// PROBLEM 3
// ---------
//
// Implement the methods ~ty_expr~ and ~ty_stmt~ according to the spec
// and the signatures below. This will, of course, require you to
// implement a couple other functions, e.g., for type compatibility
// and writability.
//
// Note: One notable difference between this and the OCaml version is
// that we can take the context to be mutable.  So type checking
// should take a mutable reference to ~self~ and update it
// accordingly.

// Note: I've included a method ~get_derefs~ which essentially does
// typing for place expressions.  Feel free to use it or delete it.

impl Context {
    fn get_derefs(&self, derefs: u8, var: Ident) -> Option<SlotTy> {
        let mut slot = self.get(&var)?;
        for _ in 0..derefs {
            match slot.ty {
                Ty::Borrow(y) => slot = self.get(&y)?,
                _ => return None,
            }
        }
        Some(*slot)
    }

    fn ty_expr(&mut self, e: &Expr) -> Option<Ty> {
        todo!()
    }

    fn ty_stmt(&mut self, s: &Stmt) -> Option<()> {
        todo!()
    }

    fn ty_prog(&mut self, p : &Prog) -> Option<Ty> {
        for stmt in p.stmts.iter() {
            self.ty_stmt(stmt)?
        }
        self.ty_expr(&p.expr)
    }
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum Value {
    Unit,
    Int32(i32),
    Loc(Ident),
}

impl Value {
    fn unit() -> Value {
        Value::Unit
    }

    fn int32(n: i32) -> Value {
        Value::Int32(n)
    }

    fn loc(x: Ident) -> Value {
        Value::Loc(x)
    }
}

#[derive(Clone, PartialEq, Debug)]
struct Store(HashMap<Ident, Value>);

impl<const N: usize> From<[(Ident, Value); N]> for Store {
    fn from(bindings: [(Ident, Value); N]) -> Store {
        Store(HashMap::from(bindings))
    }
}

impl Deref for Store {
    type Target = HashMap<Ident, Value>;

    fn deref(&self) -> &HashMap<Ident, Value> {
        &self.0
    }
}

impl DerefMut for Store {
    fn deref_mut(&mut self) -> &mut HashMap<Ident, Value> {
        &mut self.0
    }
}

// ---------
// PROBLEM 4
// ---------
//
// Implement the methods ~eval_expr~ and ~eval_stmt~ according to the
// spec and the signatures below.  As with typing, we can take the
// store to be mutable, and so the methods take a mutable reference to
// ~self~.
//
// Note: As usual, you can ~panic!()~ in branches (or unwrap to your
// hearts delight) as long as it works for well-typed programs.

impl Store {
    fn new() -> Store {
        Store(HashMap::new())
    }

    fn eval_expr(&mut self, e: &Expr) -> Value {
        todo!()
    }

    fn eval_stmt(&mut self, s: &Stmt) {
        todo!()
    }

    fn eval_prog(&mut self, p: &Prog) -> Value {
        for stmt in p.stmts.iter() {
            self.eval_stmt(stmt);
        }
        self.eval_expr(&p.expr)
    }
}

const X: u32 = 0;
const Y: u32 = 1;
const Z: u32 = 2;
const A: u32 = 3;
const B: u32 = 4;
const C: u32 = 5;

const I : Mutability = Mutability::Imm;
const M : Mutability = Mutability::Mut;

fn main() {
    // let mut x = 2;
    // let mut y = 3;
    // x = 5;
    let p = Prog::from([
        Stmt::let_mut(X, Expr::int32(2)),
        Stmt::let_imm(Y, Expr::int32(3)),
        Stmt::assign(X, Expr::int32(5)),
    ]);
    let _ = Context::new().ty_prog(&p);
    let mut store = Store::new();
    store.eval_prog(&p);
    println!("{:?}", store);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    // ∅ ⊢ () : () ⊣ ∅
    fn ty_unit() {
        let mut gamma = Context::new();
        let e = Expr::unit();
        assert_eq!(
            Some(Ty::unit()),
            gamma.ty_expr(&e),
        );
    }

    #[test]
    // ∅ ⊢ 42 : i32 ⊣ ∅
    fn ty_int32() {
        let mut gamma = Context::new();
        let e = Expr::int32(42);
        assert_eq!(
            Some(Ty::int32()),
            gamma.ty_expr(&e),
        )
    }

    // Γ = { x ↦ ⟨ i32, imm ⟩ , y ↦ ⟨ &x, imm ⟩ , z ↦ ⟨ &y , imm ⟩ }
    fn gamma2() -> Context {
        Context::from([
            (X, Ty::int32(), I),
            (Y, Ty::borrow(X), I),
            (Z, Ty::borrow(Y), I),
        ])
    }

    #[test]
    // Γ ⊬ a : ???
    fn ty_var_not_in() {
        assert_eq!(None, gamma2().ty_expr(&Expr::place(0, A)));
    }

    #[test]
    // Γ ⊢ z : &y ⊣ Γ
    fn ty_var() {
        assert_eq!(Some(Ty::borrow(Y)), gamma2().ty_expr(&Expr::place(0, Z)));
    }

    #[test]
    // Γ ⊢ *z : &x ⊣ Γ
    fn ty_deref() {
        assert_eq!(Some(Ty::borrow(X)), gamma2().ty_expr(&Expr::place(1, Z)));
    }

    #[test]
    // Γ ⊢ **z : &i32 ⊣ Γ
    fn ty_dderef() {
        assert_eq!(Some(Ty::int32()), gamma2().ty_expr(&Expr::place(2, Z)));
    }

    #[test]
    // Γ ⊬ ***z
    fn ty_ddderef() {
        assert_eq!(None, gamma2().ty_expr(&Expr::place(3, Z)));
    }

    #[test]
    // Γ ⊬ &a
    fn ty_borrow_not_in() {
        assert_eq!(None, gamma2().ty_expr(&Expr::borrow(0, A)));
    }

    #[test]
    // Γ ⊢ &x : &x ⊣ Γ
    fn ty_borrow_var() {
        assert_eq!(Some(Ty::borrow(X)), gamma2().ty_expr(&Expr::borrow(0, X)));
    }


    #[test]
    // Γ ⊢ &*y : &x ⊣ Γ
    fn ty_borrow_deref() {
        assert_eq!(Some(Ty::borrow(X)), gamma2().ty_expr(&Expr::borrow(1, Y)));
    }

    #[test]
    // Γ ⊢ &*z : &y ⊣ Γ
    fn ty_borrow_deref2() {
        assert_eq!(Some(Ty::borrow(Y)), gamma2().ty_expr(&Expr::borrow(1, Z)));
    }

    #[test]
    // Γ ⊢ &**z : &x ⊣ Γ
    fn ty_borrow_dderef() {
        assert_eq!(Some(Ty::borrow(X)), gamma2().ty_expr(&Expr::borrow(2, Z)));
    }

    #[test]
    // Γ ⊬ &***z
    fn ty_borrow_ddderef() {
        assert_eq!(None, gamma2().ty_expr(&Expr::borrow(3, Z)));
    }

    // Γ = { x ↦ ⟨ i32, imm ⟩ , y ↦ ⟨ (), mut ⟩ , z ↦ ⟨ i32, mut ⟩ , b ↦ ⟨ &z, mut ⟩  }
    fn gamma3() -> Context {
        Context::from([
            (X, Ty::int32(), I),
            (Y, Ty::unit(), M),
            (Z, Ty::int32(), M),
            (B, Ty::borrow(Z), M),
        ])
    }

    #[test]
    // Γ ⊬ a = 3
    fn ty_assign_not_in() {
        assert_eq!(None, gamma3().ty_expr(&Expr::assign(A, Expr::int32(3))));
    }

    #[test]
    // Γ ⊬ x = 3
    fn ty_assign_not_mut() {
        assert_eq!(None, gamma3().ty_expr(&Expr::assign(X, Expr::int32(3))));
    }

    #[test]
    // Γ ⊬ z = 3
    fn ty_assign_ty_not_match() {
        assert_eq!(None, gamma3().ty_expr(&Expr::assign(Z, Expr::int32(3))));
    }

    #[test]
    // Γ ⊢ b = &x ⊣ Γ[b ↦ ⟨ &x , mut ⟩]
    fn ty_assign_brw() {
        let mut gamma = gamma3();
        let mut gamma_after = gamma3();
        gamma_after.insert(B, SlotTy::new(Ty::borrow(X), M));
        assert_eq!(Some(Ty::unit()), gamma.ty_expr(&Expr::assign(B, Expr::borrow(0, X))));
        assert_eq!(gamma_after, gamma);
    }

    fn gamma4() -> Context {
        Context::from([
            (X, Ty::int32(), I),
            (Z, Ty::int32(), I),
            (B, Ty::borrow(Z), M),
            (C, Ty::borrow(X), I),
        ])
    }

    #[test]
    // Γ ⊢ b = &*c ⊣ Γ[b ↦ &x]
    fn ty_assign_borrow_deref() {
        let mut gamma = gamma4();
        let mut gamma_after = gamma4();
        gamma_after.insert(B, SlotTy::new(Ty::borrow(X), M));
        assert_eq!(
            Some(Ty::unit()),
            gamma.ty_expr(&Expr::assign(B, Expr::borrow(1, C))),
        );
        assert_eq!(gamma_after, gamma)
    }

    #[test]
    // let x = 2;
    // let z = 3;
    // let mut b = &z;
    // let c = &*b;
    // b = &x;
    fn ty_prog() {
        let mut gamma1 = Context::new();
        let gamma_after = Context::from([
            (X, Ty::int32(), I),
            (Z, Ty::int32(), I),
            (B, Ty::borrow(X), M),
            (C, Ty::borrow(Z), I),
        ]);
        let prog = Prog::from([
            Stmt::let_imm(X, Expr::int32(2)),
            Stmt::let_imm(Z, Expr::int32(3)),
            Stmt::let_mut(B, Expr::borrow(0, Z)),
            Stmt::let_imm(C, Expr::borrow(1, B)),
            Stmt::assign(B, Expr::borrow(0, X)),
        ]);
        assert_eq!(
            Some(Ty::unit()),
            gamma1.ty_prog(&prog),
        );
        assert_eq!(
            gamma_after,
            gamma1,
        );
        assert_eq!(
            None,
            gamma1.ty_expr(&Expr::assign(X, Expr::int32(4))),
        );
    }

    #[test]
    // ⟨ S , () ⟩ ⇓ ⟨ S , () ⟩
    fn eval_unit() {
        let mut s = Store::new();
        assert_eq!(
            Value::unit(),
            s.eval_expr(&Expr::unit()),
        );
    }

    #[test]
    // ⟨ S , 42 ⟩ ⇓ ⟨ S , 42 ⟩
    fn eval_int32() {
        let mut s = Store::new();
        assert_eq!(
            Value::int32(42),
            s.eval_expr(&Expr::int32(42)),
        );
    }

    // S = { x ↦ 2 , y ↦ l(x) , z ↦ l(y) }
    fn store1() -> Store {
        Store::from([
            (X, Value::int32(2)),
            (Y, Value::loc(X)),
            (Z, Value::loc(Y)),
        ])
    }

    #[test]
    // ⟨ S , x ⟩ ⇓ ⟨ S , 2 ⟩
    fn eval_var() {
        assert_eq!(Value::int32(2), store1().eval_expr(&Expr::place(0, X)));
    }

    #[test]
    // ⟨ S , y ⟩ ⇓ ⟨ S , l(x) ⟩
    fn eval_var_to_loc() {
        assert_eq!(Value::loc(X), store1().eval_expr(&Expr::place(0, Y)));
    }


    #[test]
    // ⟨ S , *y ⟩ ⇓ ⟨ S , 2 ⟩
    fn eval_deref() {
        assert_eq!(Value::int32(2), store1().eval_expr(&Expr::place(1, Y)),);
    }

    #[test]
    // ⟨ S , *z ⟩ ⇓ ⟨ S , l(x) ⟩
    fn eval_deref2() {
        assert_eq!(Value::loc(X), store1().eval_expr(&Expr::place(1, Z)));
    }

    #[test]
    // ⟨ S , **z ⟩ ⇓ ⟨ S , 2 ⟩
    fn eval_dderef() {
        assert_eq!(Value::int32(2), store1().eval_expr(&Expr::place(2, Z)));
    }


    #[test]
    #[should_panic]
    // ⟨ S , ***z ⟩ ⇓ ⊥
    fn eval_ddderef_panic() {
        store1().eval_expr(&Expr::place(3, Z));
    }

    #[test]
    // ⟨ S , &z ⟩ ⇓ ⟨ S , l(z) ⟩
    fn eval_borrow() {
        assert_eq!(Value::loc(Z), store1().eval_expr(&Expr::borrow(0, Z)));
    }

    #[test]
    // ⟨ S , &*z ⟩ ⇓ ⟨ S , l(y) ⟩
    fn eval_borrow_deref() {
        assert_eq!(Value::loc(Y), store1().eval_expr(&Expr::borrow(1, Z)));
    }

    #[test]
    // ⟨ S , &**z ⟩ ⇓ ⟨ S , l(x) ⟩
    fn eval_borrow_dderef() {
        assert_eq!(Value::loc(X), store1().eval_expr(&Expr::borrow(2, Z)));
    }

    #[test]
    #[should_panic]
    // ⟨ S , &***z ⟩ ⇓ ⊥
    fn eval_borrow_panic() {
        store1().eval_expr(&Expr::borrow(3, Z));
    }

    // S = {
    //   x ↦ 2,
    //   y ↦ l(x),
    //   z ↦ l(y),
    //   a ↦ 3,
    //   b ↦ l(a),
    // }
    fn store2() -> Store {
        Store::from([
            (X, Value::int32(2)),
            (Y, Value::loc(X)),
            (Z, Value::loc(Y)),
            (A, Value::int32(3)),
            (B, Value::loc(A)),
        ])
    }

    #[test]
    // ⟨ S , x = 5 ⟩ ⇓ ⟨ S[x ↦ 5] , () ⟩
    fn eval_assign_int32() {
        let mut store = store2();
        let mut store_after = store2();
        store_after.insert(X, Value::int32(5));
        assert_eq!(
            Value::unit(),
            store.eval_expr(&Expr::assign(X, Expr::int32(5))),
        );
        assert_eq!(store_after, store);
    }

    #[test]
    // ⟨ S , b = &**z ⟩ ⇓ ⟨ S[b ↦ l(x)] , () ⟩
    fn eval_assign_brw_deref() {
        let mut store = store2();
        let mut store_after = store2();
        store_after.insert(B, Value::loc(X));
        assert_eq!(
            Value::unit(),
            store.eval_expr(&Expr::assign(B, Expr::borrow(2, Z))),
        );
        assert_eq!(store_after, store);
    }

    #[test]
    // let x = 2;
    // let z = 3;
    // let mut b = &z;
    // let c = &*b;
    // b = &x;
    fn eval_prog() {
        let mut store = Store::new();
        let store_after = Store::from([
            (X, Value::int32(2)),
            (Z, Value::int32(3)),
            (B, Value::loc(X)),
            (C, Value::loc(Z)),
        ]);
        let prog = Prog::from([
            Stmt::let_imm(X, Expr::int32(2)),
            Stmt::let_imm(Z, Expr::int32(3)),
            Stmt::let_mut(B, Expr::borrow(0, Z)),
            Stmt::let_imm(C, Expr::borrow(1, B)),
            Stmt::assign(B, Expr::borrow(0, X)),
        ]);
        assert_eq!(
            Value::unit(),
            store.eval_prog(&prog),
        );
        assert_eq!(
            store_after,
            store,
        );
    }
}
