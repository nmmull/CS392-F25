#![feature(dropck_eyepatch)]

struct PrintOnDrop<'a>(&'a str);

impl<'a> Drop for PrintOnDrop<'a> {
    fn drop(&mut self) {
        println!("{}", self.0);
    }
}

fn main() {
    // let x = String::from("foo");
    // let y = Rc::new(x);
    // let z = Rc::clone(&y);
    // println!("{}", *y);
    // println!("{}", *z);

    let x = String::from("foo");
    let y = Rc::new(&x);
    println!("{}", *y);
    drop(x);
    // drop(y)
}

struct Rc<T> {
    ptr: std::ptr::NonNull<Inner<T>>,
    _own_t: std::marker::PhantomData<T>,
}

// fn foo<'a, 'b: 'a, T>(x: Rc<&'b T>) -> Rc<&'a T> {
//     x
// }

struct Inner<T> {
    count: std::cell::Cell<usize>,
    value: T,
}

impl<T> Rc<T> {
    fn new(value: T) -> Rc<T> {
        unsafe {
            Rc {
                ptr: std::ptr::NonNull::new(
                    Box::into_raw(Box::new(Inner {
                        count: std::cell::Cell::new(1),
                        value,
                    }))).unwrap_unchecked(),
                _own_t : std::marker::PhantomData,

            }
        }
    }
}

impl<T> std::ops::Deref for Rc<T> {
    type Target = T;

    fn deref(&self) -> &T {
        unsafe { &self.ptr.as_ref().value }
    }
}

impl<T> Clone for Rc<T> {
    fn clone(&self) -> Rc<T> {
        // increment the counter
        unsafe {
            let inner_ref = self.ptr.as_ref();
            inner_ref.count.set(inner_ref.count.get() + 1);
        }
        Rc { ptr: self.ptr, _own_t : std::marker::PhantomData }
    }
}

unsafe impl<#[may_dangle] T> Drop for Rc<T> {
    fn drop(&mut self) {
        // decrement the counter
        // if counter is 0, then drop the inner value
        let inner = unsafe { self.ptr.as_ref() };
        inner.count.set(inner.count.get() - 1);
        if inner.count.get() == 0 {
            println!("actually dropped");
            unsafe { drop(Box::from_raw(self.ptr.as_ptr())); }
        }
    }
}
